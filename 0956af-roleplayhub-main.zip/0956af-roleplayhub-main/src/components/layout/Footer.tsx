import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    {
      title: 'Navigation',
      links: [
        { name: 'Home', path: '/' },
        { name: 'Community', path: '/community' },
        { name: 'Servers', path: '/servers' },
        { name: 'Features', path: '/features' },
      ],
    },
    {
      title: 'Resources',
      links: [
        { name: 'Help Center', path: '/help' },
        { name: 'Support', path: '/support' },
        { name: 'Changelog', path: '/changelog' },
        { name: 'Status', path: '/status' },
      ],
    },
    {
      title: 'Legal',
      links: [
        { name: 'Terms of Service', path: '/terms' },
        { name: 'Privacy Policy', path: '/privacy' },
        { name: 'Cookie Policy', path: '/cookies' },
      ],
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <footer className="relative w-full bg-card border-t border-border">
      {/* Main Footer Content */}
      <div className="mx-auto max-w-7xl px-6 md:px-12 py-16 md:py-20">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 mb-12"
        >
          {/* Brand */}
          <motion.div variants={itemVariants}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-primary flex items-center justify-center text-white font-bold">
                RP
              </div>
              <div>
                <h3 className="font-bold text-foreground">RolePlay Hub</h3>
                <p className="text-xs text-foreground/60">NRW RP Germany</p>
              </div>
            </div>
            <p className="text-sm text-foreground/70 leading-relaxed">
              The ultimate German roleplay community platform with immersive gameplay, diverse servers, and a vibrant player base.
            </p>
          </motion.div>

          {/* Links Sections */}
          {footerLinks.map((section, idx) => (
            <motion.div key={idx} variants={itemVariants}>
              <h4 className="font-semibold text-foreground mb-4">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link, linkIdx) => (
                  <li key={linkIdx}>
                    <Link
                      to={link.path}
                      className="text-sm text-foreground/70 hover:text-primary transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>

        {/* Divider */}
        <div className="h-px bg-border my-8" />

        {/* Bottom Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          className="flex flex-col md:flex-row items-center justify-between gap-6"
        >
          {/* Copyright */}
          <motion.p variants={itemVariants} className="text-sm text-foreground/60 text-center md:text-left">
            © {currentYear} NRW RP DE. All rights reserved. Made with{' '}
            <Heart className="inline w-4 h-4 text-primary mx-1" />
            by the RolePlay Hub Team.
          </motion.p>

          {/* Social Links */}
          <motion.div variants={itemVariants} className="flex items-center gap-4">
            {[
              { name: 'Discord', icon: '💬', url: 'https://discord.gg/yourserver' },
              { name: 'Twitter', icon: '𝕏', url: 'https://twitter.com/yourprofile' },
              { name: 'GitHub', icon: '⚙️', url: 'https://github.com/yourprofile' },
            ].map((social, idx) => (
              <a
                key={idx}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-border hover:bg-primary hover:text-white flex items-center justify-center transition-all duration-300 hover:scale-110"
                title={social.name}
              >
                {social.icon}
              </a>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-border py-4 px-6 md:px-12 text-center md:text-left">
        <p className="text-xs text-foreground/50">
          Powered by modern web technologies • React • Vite • Tailwind CSS
        </p>
      </div>
    </footer>
  );
};

export default Footer;
