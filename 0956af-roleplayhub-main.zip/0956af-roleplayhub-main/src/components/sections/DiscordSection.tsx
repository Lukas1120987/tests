import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { MessageCircle, Users, Zap } from 'lucide-react';

const DiscordSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  };

  return (
    <section ref={ref} className="relative w-full py-20 md:py-32 px-6 md:px-12">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-accent/5 -z-10" />

      <div className="mx-auto max-w-5xl">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="relative"
        >
          {/* Main Card */}
          <motion.div
            variants={itemVariants}
            className="relative rounded-2xl overflow-hidden border border-border"
          >
            {/* Gradient Background */}
            <div className="absolute inset-0 bg-gradient-primary opacity-5" />

            <div className="relative p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
              {/* Left Content */}
              <motion.div variants={itemVariants} className="flex-1 text-center md:text-left">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Join Our Discord Community
                </h2>
                <p className="text-lg text-foreground/70 mb-6">
                  Connect with players, get support, participate in events, and stay updated on the latest news and announcements.
                </p>

                {/* Features List */}
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate={isInView ? 'visible' : 'hidden'}
                  className="flex flex-col gap-3 mb-8"
                >
                  {[
                    { icon: <MessageCircle className="w-5 h-5" />, text: 'Real-time chat and support' },
                    { icon: <Users className="w-5 h-5" />, text: 'Connect with 15K+ community members' },
                    { icon: <Zap className="w-5 h-5" />, text: 'Exclusive announcements and events' },
                  ].map((feature, idx) => (
                    <motion.div
                      key={idx}
                      variants={itemVariants}
                      className="flex items-center gap-3 text-foreground/80"
                    >
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                        {feature.icon}
                      </div>
                      {feature.text}
                    </motion.div>
                  ))}
                </motion.div>

                {/* CTA Button */}
                <motion.a
                  variants={itemVariants}
                  href="https://discord.gg/yourserver"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary px-8 py-4 text-lg inline-flex items-center gap-2 hover:shadow-lg transition-all group"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.317 4.37a19.791 19.791 0 00-4.885-1.515.074.074 0 00-.079.037c-.211.375-.444.864-.607 1.25a18.27 18.27 0 00-5.487 0c-.163-.386-.395-.875-.607-1.25a.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 00-.042-.106 13.107 13.107 0 01-1.872-.892.077.077 0 01-.008-.128 10.2 10.2 0 00.372-.294.075.075 0 01.078-.01c3.928 1.793 8.18 1.793 12.062 0a.075.075 0 01.079.009c.12.098.246.198.373.295a.077.077 0 01-.006.127 12.299 12.299 0 01-1.873.892.076.076 0 00-.041.107c.352.699.764 1.364 1.225 1.994a.077.077 0 00.084.028 19.839 19.839 0 006.002-3.03.076.076 0 00.032-.057c.5-4.565-.838-8.628-3.549-12.193a.061.061 0 00-.031-.03zM8.02 15.33c-1.183 0-2.157-.965-2.157-2.156 0-1.193.964-2.157 2.157-2.157 1.193 0 2.157.964 2.157 2.157 0 1.19-.965 2.156-2.157 2.156zm7.975 0c-1.183 0-2.157-.965-2.157-2.156 0-1.193.964-2.157 2.157-2.157 1.193 0 2.157.964 2.157 2.157 0 1.19-.964 2.156-2.157 2.156z" />
                  </svg>
                  Join Now
                  <span className="group-hover:translate-x-1 transition-transform">→</span>
                </motion.a>
              </motion.div>

              {/* Right Decoration */}
              <motion.div
                variants={itemVariants}
                className="hidden md:block flex-1"
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
              >
                <div className="w-48 h-48 rounded-2xl bg-gradient-primary opacity-10 blur-3xl" />
              </motion.div>
            </div>
          </motion.div>

          {/* Floating Elements */}
          <motion.div
            className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-primary opacity-5 blur-2xl"
            animate={{ y: [0, 15, 0], x: [0, 10, 0] }}
            transition={{ duration: 6, repeat: Infinity }}
          />
          <motion.div
            className="absolute -bottom-6 -left-6 w-32 h-32 rounded-full bg-accent opacity-5 blur-3xl"
            animate={{ y: [0, -15, 0], x: [0, -10, 0] }}
            transition={{ duration: 5, repeat: Infinity }}
          />
        </motion.div>
      </div>
    </section>
  );
};

export default DiscordSection;
