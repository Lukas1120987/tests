import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const updateCanvasSize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    updateCanvasSize();

    // Particles system
    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      opacity: number;
      targetOpacity: number;
    }

    const particles: Particle[] = [];

    // Create particles
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.offsetWidth,
        y: Math.random() * canvas.offsetHeight,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        radius: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.3,
        targetOpacity: Math.random() * 0.5 + 0.3,
      });
    }

    const animate = () => {
      // Clear canvas
      ctx.fillStyle = 'hsl(var(--background))';
      ctx.fillRect(0, 0, canvas.offsetWidth, canvas.offsetHeight);

      // Update and draw particles
      particles.forEach((p, i) => {
        // Update position
        p.x += p.vx;
        p.y += p.vy;

        // Bounce off edges
        if (p.x < 0 || p.x > canvas.offsetWidth) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.offsetHeight) p.vy *= -1;

        // Wrap around
        p.x = (p.x + canvas.offsetWidth) % canvas.offsetWidth;
        p.y = (p.y + canvas.offsetHeight) % canvas.offsetHeight;

        // Smooth opacity animation
        p.opacity += (p.targetOpacity - p.opacity) * 0.02;

        // Draw particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(var(--primary), ${p.opacity})`;
        ctx.fill();

        // Draw connections to nearby particles
        particles.forEach((p2, j) => {
          if (i >= j) return;
          const dx = p2.x - p.x;
          const dy = p2.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 150) {
            ctx.strokeStyle = `hsla(var(--primary), ${(p.opacity + p2.opacity) / 4})`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        });
      });

      // Mouse attraction
      particles.forEach((p) => {
        const dx = mousePos.x - p.x;
        const dy = mousePos.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 200) {
          const force = 0.5 * (1 - dist / 200);
          p.vx += (dx / dist) * force * 0.1;
          p.vy += (dy / dist) * force * 0.1;
        }
      });

      requestAnimationFrame(animate);
    };

    animate();

    // Mouse tracking
    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      setMousePos({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    };

    // Resize handler
    const handleResize = () => {
      updateCanvasSize();
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
    };
  }, [mousePos]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  };

  return (
    <section className="relative w-full h-screen md:h-[calc(100vh-80px)] flex items-center justify-center overflow-hidden pt-16 md:pt-0">
      {/* Canvas Background */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        style={{ background: 'hsl(var(--background))' }}
      />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-subtle opacity-40" />

      {/* Content */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        className="relative z-10 mx-auto max-w-4xl px-6 md:px-12 text-center"
      >
        {/* Badge */}
        <motion.div variants={itemVariants} className="mb-6">
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary font-semibold text-sm border border-primary/20">
            Welcome to NRW RP DE
          </span>
        </motion.div>

        {/* Main Heading */}
        <motion.h1
          variants={itemVariants}
          className="text-4xl md:text-7xl font-bold text-foreground mb-6 leading-tight"
        >
          Experience the Ultimate
          <span className="bg-gradient-primary bg-clip-text text-transparent"> Roleplay </span>
          Community
        </motion.h1>

        {/* Description */}
        <motion.p
          variants={itemVariants}
          className="text-lg md:text-xl text-foreground/70 mb-8 max-w-2xl mx-auto leading-relaxed"
        >
          Join thousands of players in the most immersive German roleplay experience. Create your story, build relationships, and shape your destiny.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          variants={itemVariants}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <Link
            to="/servers"
            className="btn-primary px-8 py-4 text-lg group"
          >
            Explore Servers
            <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Link>
          <a
            href="https://discord.gg/yourserver"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary px-8 py-4 text-lg"
          >
            Join Discord
          </a>
        </motion.div>

        {/* Stats Preview */}
        <motion.div
          variants={itemVariants}
          className="mt-12 grid grid-cols-3 gap-4 md:gap-8 text-center"
        >
          <div className="p-4">
            <div className="text-2xl md:text-4xl font-bold text-primary">5+</div>
            <p className="text-xs md:text-sm text-foreground/60 mt-2">Active Servers</p>
          </div>
          <div className="p-4">
            <div className="text-2xl md:text-4xl font-bold text-primary">10K+</div>
            <p className="text-xs md:text-sm text-foreground/60 mt-2">Community Members</p>
          </div>
          <div className="p-4">
            <div className="text-2xl md:text-4xl font-bold text-primary">24/7</div>
            <p className="text-xs md:text-sm text-foreground/60 mt-2">Always Online</p>
          </div>
        </motion.div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20"
      >
        <div className="flex flex-col items-center gap-2">
          <p className="text-sm text-foreground/60">Scroll to explore</p>
          <div className="w-6 h-10 rounded-full border-2 border-foreground/30 flex items-center justify-center">
            <div className="w-1 h-2 bg-foreground/60 rounded-full" />
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;
