import { motion, useInView } from 'framer-motion';
import { useRef } from 'react';
import { Zap, Users, Shield, Gamepad2, Crown, Rocket } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Highlight {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  href: string;
}

const HighlightsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const highlights: Highlight[] = [
    {
      title: 'Multiple Servers',
      description: 'Choose from our diverse collection of roleplay servers, each with unique gameplay styles and communities.',
      icon: <Gamepad2 className="w-8 h-8" />,
      color: 'from-blue-500 to-cyan-500',
      href: '/servers',
    },
    {
      title: 'Vibrant Community',
      description: 'Connect with thousands of players, make friends, and participate in events and competitions.',
      icon: <Users className="w-8 h-8" />,
      color: 'from-purple-500 to-pink-500',
      href: '/community',
    },
    {
      title: 'Professional Staff',
      description: 'Our experienced team ensures a safe, fair, and enjoyable experience for all players.',
      icon: <Shield className="w-8 h-8" />,
      color: 'from-green-500 to-emerald-500',
      href: '/settings',
    },
    {
      title: 'Advanced Features',
      description: 'Custom scripts, realistic economy, dynamic jobs, and immersive roleplay mechanics.',
      icon: <Zap className="w-8 h-8" />,
      color: 'from-orange-500 to-red-500',
      href: '/features',
    },
    {
      title: 'Premium Experience',
      description: 'VIP features, exclusive content, priority support, and special in-game benefits.',
      icon: <Crown className="w-8 h-8" />,
      color: 'from-yellow-500 to-orange-500',
      href: '/servers',
    },
    {
      title: 'Continuous Growth',
      description: 'Regular updates, new features, and expansions to keep the experience fresh and exciting.',
      icon: <Rocket className="w-8 h-8" />,
      color: 'from-indigo-500 to-purple-500',
      href: '/global',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  };

  return (
    <section ref={ref} className="relative w-full py-20 md:py-32 px-6 md:px-12">
      {/* Background Gradient */}
      <div className="absolute inset-0 opacity-5 -z-10">
        <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-primary rounded-full mix-blend-multiply filter blur-3xl" />
        <div className="absolute top-1/2 right-1/4 w-96 h-96 bg-accent rounded-full mix-blend-multiply filter blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 md:mb-20"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Why Choose NRW RP DE?
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            We offer the most immersive and engaging roleplay experience with features that set us apart from the competition.
          </p>
        </motion.div>

        {/* Highlights Grid */}
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {highlights.map((highlight, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              whileHover={{ y: -8 }}
              transition={{ type: 'spring', stiffness: 200, damping: 20 }}
            >
              <Link to={highlight.href} className="block h-full">
                <div className="card-base h-full flex flex-col cursor-pointer border border-border hover:border-primary/50 group">
                  {/* Icon Container */}
                  <div className={`mb-4 w-14 h-14 rounded-xl bg-gradient-to-br ${highlight.color} flex items-center justify-center text-white group-hover:scale-110 transition-transform duration-300`}>
                    {highlight.icon}
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                    {highlight.title}
                  </h3>
                  <p className="text-foreground/70 flex-1 text-sm leading-relaxed">
                    {highlight.description}
                  </p>

                  {/* CTA Arrow */}
                  <div className="mt-4 flex items-center gap-2 text-primary font-semibold text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                    <span>Learn more</span>
                    <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HighlightsSection;
