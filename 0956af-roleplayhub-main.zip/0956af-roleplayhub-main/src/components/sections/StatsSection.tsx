import { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import CountupNumber from '@/components/ui/CountupNumber';

interface Stat {
  label: string;
  value: number;
  suffix?: string;
  icon?: string;
}

const StatsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const stats: Stat[] = [
    { label: 'Active Players', value: 10420, suffix: '+' },
    { label: 'Roleplay Hours', value: 2500000, suffix: '+' },
    { label: 'Community Members', value: 15300, suffix: '+' },
    { label: 'Servers Online', value: 7, suffix: '' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  };

  return (
    <section ref={ref} className="relative w-full py-20 md:py-32 px-6 md:px-12">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-subtle opacity-30 -z-10" />

      <div className="mx-auto max-w-6xl">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16 md:mb-20"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Our Growing Community
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Join thousands of players who are already experiencing the best roleplay server in Germany
          </p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8"
        >
          {stats.map((stat, idx) => (
            <motion.div
              key={idx}
              variants={itemVariants}
              className="group relative"
            >
              {/* Gradient Background */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              {/* Card */}
              <div className="relative card-base border border-border hover:border-primary/30 text-center">
                {/* Number with counter animation */}
                <div className="mb-3">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.8 }}
                    transition={{ delay: 0.1 * (idx + 1), duration: 0.5 }}
                    className="text-3xl md:text-5xl font-bold bg-gradient-primary bg-clip-text text-transparent"
                  >
                    {isInView && (
                      <CountupNumber
                        from={0}
                        to={stat.value}
                        duration={2}
                        suffix={stat.suffix || ''}
                      />
                    )}
                  </motion.div>
                </div>

                {/* Label */}
                <p className="text-sm md:text-base font-semibold text-foreground/80">
                  {stat.label}
                </p>

                {/* Accent Line */}
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={isInView ? { scaleX: 1 } : { scaleX: 0 }}
                  transition={{ delay: 0.2 * (idx + 1), duration: 0.5 }}
                  className="mt-4 h-1 w-8 mx-auto bg-gradient-primary rounded-full origin-left"
                />
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <p className="text-foreground/60 max-w-2xl mx-auto">
            These numbers are growing every day. Join us and become part of the fastest-growing roleplay community in Germany.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default StatsSection;
