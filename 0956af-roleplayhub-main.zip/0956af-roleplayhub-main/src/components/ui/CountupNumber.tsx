import { useEffect, useState } from 'react';

interface CountupNumberProps {
  from: number;
  to: number;
  duration: number;
  suffix?: string;
  prefix?: string;
  formatter?: (value: number) => string;
}

const CountupNumber = ({
  from,
  to,
  duration,
  suffix = '',
  prefix = '',
  formatter,
}: CountupNumberProps) => {
  const [count, setCount] = useState(from);

  useEffect(() => {
    let startTime: number | null = null;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / (duration * 1000), 1);

      // Easing function for smooth animation
      const easeOutQuad = 1 - Math.pow(1 - progress, 2);

      setCount(Math.floor(from + (to - from) * easeOutQuad));

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setCount(to);
      }
    };

    requestAnimationFrame(animate);
  }, [from, to, duration]);

  const formatNumber = (num: number) => {
    if (formatter) return formatter(num);
    
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    }
    return num.toLocaleString();
  };

  return (
    <>
      {prefix}
      {formatNumber(count)}
      {suffix}
    </>
  );
};

export default CountupNumber;
